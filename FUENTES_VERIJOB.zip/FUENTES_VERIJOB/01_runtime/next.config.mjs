/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next 16: Turbopack está ON por defecto.
  // Definimos turbopack vacío para que no falle si también existe config de webpack.
  turbopack: {},

  // Esto ayuda con iCloud/CloudDocs para evitar watchers problemáticos.
  webpack: (config) => {
    config.watchOptions = {
      ignored: ["**/node_modules", "**/.next", "**/.git"],
    };
    return config;
  },
};

export default nextConfig;
