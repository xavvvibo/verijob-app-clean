Exporta desde Supabase:
1) Schema (tablas, views, funciones) sin datos
2) Policies RLS
3) Storage policies / buckets

Pega el SQL en:
- schema.sql
- rls_policies.sql
- storage_policies.sql
