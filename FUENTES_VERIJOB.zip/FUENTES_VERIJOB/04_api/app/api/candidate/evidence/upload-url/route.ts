// --- EVIDENCE UPLOAD BACKBONE (SECURE) ---
// 1) Auth server-side via Supabase SSR cookie session
// 2) Validate mime/type/size + sanitize filename
// 3) Register verification_action "evidence_uploaded"
// 4) Optionally return a signed upload URL + storage path (backward-compatible)

import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";
import { randomUUID } from "crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const DEFAULT_MAX_MB = 20; // ajusta si quieres
const MAX_BYTES = (Number(process.env.MAX_EVIDENCE_MB || DEFAULT_MAX_MB) || DEFAULT_MAX_MB) * 1024 * 1024;

// Ajusta lista si necesitas más tipos
const ALLOWED_MIME = new Set<string>([
  "application/pdf",
  "image/jpeg",
  "image/png",
]);

function sanitizeFilename(name: string) {
  const base = (name || "upload").split("/").pop()!.split("\\").pop()!;
  const cleaned = base
    .replace(/\s+/g, "_")
    .replace(/[^A-Za-z0-9._-]/g, "")
    .slice(0, 80);

  // Evitar nombres vacíos o raros
  return cleaned.length ? cleaned : "upload";
}

function extFrom(filename: string, mimeType: string) {
  const m = filename.match(/\.([A-Za-z0-9]+)$/);
  if (m?.[1]) return m[1].toLowerCase();
  // fallback simple
  if (mimeType === "application/pdf") return "pdf";
  if (mimeType === "image/jpeg") return "jpg";
  if (mimeType === "image/png") return "png";
  return "bin";
}

export async function POST(req: Request) {
  // 1) Auth (NO confiar en user del body)
  const supabase = await createClient();
  const { data: auth, error: authErr } = await supabase.auth.getUser();

  if (authErr || !auth?.user) {
    return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  }

  const userId = auth.user.id;

  // 2) Parse body
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const filename = sanitizeFilename(String(body?.filename || ""));
  const mimeType = String(body?.mimeType || "");
  const size = Number(body?.size || 0);

  if (!mimeType || !ALLOWED_MIME.has(mimeType)) {
    return NextResponse.json({ error: "Unsupported file type" }, { status: 415 });
  }

  if (!Number.isFinite(size) || size <= 0) {
    return NextResponse.json({ error: "Invalid file size" }, { status: 400 });
  }

  if (size > MAX_BYTES) {
    return NextResponse.json(
      { error: `File too large (max ${(MAX_BYTES / (1024 * 1024)).toFixed(0)}MB)` },
      { status: 413 }
    );
  }

  // 3) Encontrar la última verification_request del usuario (como hacías)
  const { data: verificationRequest, error: vrErr } = await supabase
    .from("verification_requests")
    .select("id,status")
    .eq("requested_by", userId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (vrErr) {
    return NextResponse.json({ error: "Failed to fetch verification request" }, { status: 500 });
  }

  // 4) Preparar info de storage (opcional: firmar subida)
  //    IMPORTANTE: esto NO rompe el front actual: sigue devolviendo {ok:true}
  const bucket = String(process.env.EVIDENCE_BUCKET || "evidence");
  const safeExt = extFrom(filename, mimeType);
  const objectName = `${Date.now()}-${randomUUID()}.${safeExt}`;
  const storagePath = `${userId}/${objectName}`;

  let signedUploadUrl: string | null = null;

  // createSignedUploadUrl existe en supabase-js v2 (Storage)
  // Si el bucket no existe o RLS lo bloquea, simplemente no devolvemos URL (backward compatible)
  try {
    // @ts-ignore
    const { data: signed, error: signErr } = await supabase.storage
      .from(bucket)
      // @ts-ignore
      .createSignedUploadUrl(storagePath, 60 * 10); // 10 min

    if (!signErr && signed?.signedUrl) {
      signedUploadUrl = signed.signedUrl;
    }
  } catch {
    signedUploadUrl = null;
  }

  // 5) Registrar action + mover status a reviewing (si hay verificationRequest)
  if (verificationRequest?.id) {
    const meta: Record<string, any> = { filename, mimeType, size };
    // añadimos storage info si existe (útil para fases posteriores)
    meta.bucket = bucket;
    meta.storagePath = storagePath;
    meta.signedUploadUrlIssued = Boolean(signedUploadUrl);

    const { error: insErr } = await supabase.from("verification_actions").insert({
      verification_request_id: verificationRequest.id,
      actor_id: userId,
      action_type: "evidence_uploaded",
      metadata: meta,
    });

    if (!insErr) {
      await supabase
        .from("verification_requests")
        .update({ status: "reviewing" })
        .eq("id", verificationRequest.id);
    }
  }

  // 6) Response (no rompe tu front)
  return NextResponse.json({
    ok: true,
    upload: signedUploadUrl
      ? { bucket, path: storagePath, signedUploadUrl, expiresInSeconds: 600 }
      : { bucket, path: storagePath },
  });
}
