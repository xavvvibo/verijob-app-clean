import { NextResponse } from "next/server";
import { createServiceRoleClient } from "@/utils/supabase/service";
import { createClient } from "@/utils/supabase/server";
import { getClientIp, rateLimit } from "@/utils/rateLimit";
import { sanitizePublic } from "@/utils/sanitizePublic";
import { hasUpstash, limitByIp } from "@/utils/rateLimitGlobal";

type Params = { token: string };

function json(status: number, body: any) {
  const res = NextResponse.json(body, { status });
  res.headers.set("Cache-Control", "no-store");
  return res;
}

function isHex48(token: string) {
  return /^[a-f0-9]{48}$/i.test(token);
}

function isExpired(expiresAt?: string | null) {
  if (!expiresAt) return false;
  const t = Date.parse(expiresAt);
  if (Number.isNaN(t)) return false;
  return t <= Date.now();
}

export async function GET(req: Request, ctx: { params: Promise<Params> }) {
  const { token } = await ctx.params;
  const ip = getClientIp(req);
  const ua = req.headers.get("user-agent") || "";

  const rl = await (async () => {
    if (hasUpstash()) return limitByIp(ip);
    return rateLimit(`public_verification:${ip}`, 60, 5 * 60 * 1000);
  })();

  if (!rl.ok) return json(429, { error: "Too Many Requests" });

  if (!token || !isHex48(token)) {
    return json(404, { error: "Not found" });
  }

  const service = createServiceRoleClient();

  const { data: link } = await service
    .from("verification_public_links")
    .select("id, verification_id, expires_at")
    .eq("public_token", token)
    .eq("is_active", true)
    .maybeSingle();

  if (!link) return json(404, { error: "Not found" });

  if (isExpired(link.expires_at)) {
    return json(410, { error: "Link expired" });
  }

  const { data: summary } = await service
    .from("verification_public_summary")
    .select("*")
    .eq("verification_id", link.verification_id)
    .maybeSingle();

  if (!summary) return json(404, { error: "Not found" });

  await service
    .from("verification_public_links")
    .update({ last_viewed_at: new Date().toISOString() })
    .eq("id", link.id);

  // Detect logged company session
  let actorUserId: string | null = null;
  let companyId: string | null = null;

  try {
    const supa = await createClient();
    const { data: { user } } = await supa.auth.getUser();
    if (user?.id) {
      actorUserId = user.id;
      const { data: memberships } = await supa
        .from("company_members")
        .select("company_id")
        .eq("user_id", user.id);
      if (memberships?.length) {
        companyId = memberships[0].company_id;
      }
    }
  } catch {}

  // Audit
  await service.from("enterprise_audit_events").insert({
    event_type: "public_verification_viewed",
    verification_id: link.verification_id,
    company_id: companyId,
    actor_user_id: actorUserId,
    public_token_last4: token.slice(-4),
    ip,
    user_agent: ua,
  });

  // Grant if company logged
  if (companyId) {
    await service.from("enterprise_access_grants").upsert({
      company_id: companyId,
      verification_id: link.verification_id,
      granted_via_token: token,
      last_used_at: new Date().toISOString(),
    });
  }

  const safe = sanitizePublic(summary);

  return json(200, { summary: safe });
}
