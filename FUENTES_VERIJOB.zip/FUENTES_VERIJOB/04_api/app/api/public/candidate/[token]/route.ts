import { NextResponse } from "next/server";
import { createServiceRoleClient } from "@/utils/supabase/service";
import { getClientIp, rateLimit } from "@/utils/rateLimit";
import { hasUpstash, limitByIp } from "@/utils/rateLimitGlobal";
import { sanitizePublic } from "@/utils/sanitizePublic";

type Params = { token: string };

function json(status: number, body: any) {
  const res = NextResponse.json(body, { status });
  res.headers.set("Cache-Control", "no-store");
  return res;
}

function isHex48(token: string) {
  return /^[a-f0-9]{48}$/i.test(token);
}

function isExpired(expiresAt?: string | null) {
  if (!expiresAt) return false;
  const t = Date.parse(expiresAt);
  if (Number.isNaN(t)) return false;
  return t <= Date.now();
}

export async function GET(req: Request, ctx: { params: Promise<Params> }) {
  const { token } = await ctx.params;
  const ip = getClientIp(req);

  const rl = await (async () => {
    if (hasUpstash()) return limitByIp(ip);
    return rateLimit(`public_candidate:${ip}`, 60, 5 * 60 * 1000);
  })();

  if (!rl.ok) return json(429, { error: "Too Many Requests" });
  if (!token || !isHex48(token)) return json(404, { error: "Not found" });

  const service = createServiceRoleClient();

  const { data: link } = await service
    .from("candidate_public_links")
    .select("id, candidate_id, expires_at")
    .eq("public_token", token)
    .eq("is_active", true)
    .maybeSingle();

  if (!link) return json(404, { error: "Not found" });
  if (isExpired(link.expires_at)) return json(410, { error: "Link expired" });

  // Perfil: asumimos tabla public.profiles (típico). Si en tu DB no existe, te lo ajusto al momento.
  const { data: profile } = await service
    .from("profiles")
    .select("*")
    .eq("id", link.candidate_id)
    .maybeSingle();

  if (!profile) return json(404, { error: "Not found" });

  await service
    .from("candidate_public_links")
    .update({ last_viewed_at: new Date().toISOString() })
    .eq("id", link.id);

  const safe = sanitizePublic(profile);

  return json(200, { profile: safe });
}
