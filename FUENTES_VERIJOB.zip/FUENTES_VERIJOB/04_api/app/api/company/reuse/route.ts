import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";
import { createServiceRoleClient } from "@/utils/supabase/service";
import { rateLimit } from "@/utils/rateLimit";

function json(status: number, body: any) {
  const res = NextResponse.json(body, { status });
  res.headers.set("Cache-Control", "no-store");
  return res;
}

function isHex48(token: string) {
  return /^[a-f0-9]{48}$/i.test(token);
}

function isExpired(expiresAt?: string | null) {
  if (!expiresAt) return false;
  const t = Date.parse(expiresAt);
  if (Number.isNaN(t)) return false;
  return t <= Date.now();
}

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json(401, { error: "Unauthorized" });

  const rl = rateLimit(`company_reuse:${user.id}`, 60, 10 * 60 * 1000);
  if (!rl.ok) return json(429, { error: "Too Many Requests" });

  let token = "";
  try {
    const body = await req.json();
    token = String(body?.token ?? "");
  } catch {
    return json(400, { error: "Bad request" });
  }

  if (!token || !isHex48(token)) return json(404, { error: "Not found" });

  const { data: memberships } = await supabase
    .from("company_members")
    .select("company_id")
    .eq("user_id", user.id);

  if (!memberships?.length) return json(403, { error: "Forbidden" });

  const companyId = memberships[0].company_id;

  const service = createServiceRoleClient();

  const { data: publicLink } = await service
    .from("verification_public_links")
    .select("verification_id, company_id, expires_at")
    .eq("public_token", token)
    .eq("is_active", true)
    .maybeSingle();

  if (!publicLink?.verification_id) return json(404, { error: "Not found" });

  if (isExpired(publicLink.expires_at)) {
    return json(410, { error: "Link expired" });
  }

  if (publicLink.company_id && publicLink.company_id !== companyId) {
    return json(404, { error: "Not found" });
  }

  const { error } = await supabase.from("verification_reuse_events").insert({
    verification_id: publicLink.verification_id,
    company_id: companyId,
    created_by: user.id,
  });

  if (error && (error as any).code !== "23505") {
    return json(400, { error: "Insert failed" });
  }

  if (!publicLink.company_id) {
    await service
      .from("verification_public_links")
      .update({ company_id: companyId })
      .eq("public_token", token);
  }

  return json(200, { success: true });
}
