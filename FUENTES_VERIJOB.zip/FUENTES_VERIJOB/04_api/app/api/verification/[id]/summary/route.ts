import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";
import { createServiceRoleClient } from "@/utils/supabase/service";
import { rateLimit } from "@/utils/rateLimit";

export const runtime = "nodejs";

type Params = { id: string };

function json(status: number, body: any) {
  const res = NextResponse.json(body, { status });
  res.headers.set("Cache-Control", "no-store");
  return res;
}

function isUuid(v: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
}

export async function GET(_req: Request, ctx: { params: Promise<Params> }) {
  const { id } = await ctx.params;

  if (!id || !isUuid(id)) return json(404, { error: "Not found" });

  // Auth (cookie-based)
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return json(401, { error: "Unauthorized" });

  // Rate limit per user: 120 / 10 min
  const rl = rateLimit(`summary:${user.id}`, 120, 10 * 60 * 1000);
  if (!rl.ok) return json(429, { error: "Too Many Requests" });

  const admin = createServiceRoleClient();

  // 1) Load summary (bypass RLS)
  const { data: summary } = await admin
    .from("verification_summary")
    .select("*")
    .eq("verification_id", id)
    .maybeSingle();

  if (!summary) return json(404, { error: "Not found" });

  // 2) ACL: candidate can read
  if (summary.candidate_id === user.id) {
    return json(200, summary);
  }

  // 3) ACL: company members can read (if company_id exists)
  if (summary.company_id) {
    const { data: member } = await admin
      .from("company_members")
      .select("id")
      .eq("company_id", summary.company_id)
      .eq("user_id", user.id)
      .maybeSingle();

    if (member) {
      return json(200, summary);
    }
  }

  // 4) Not authorized → 404 to avoid info leaks
  return json(404, { error: "Not found" });
}
